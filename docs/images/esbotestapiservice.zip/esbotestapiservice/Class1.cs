﻿using Entersoft.Framework.Platform;
using Entersoft.Web.Api;
using Entersoft.Web.Api.Text;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace esbotestapiservice.Generic
{
    public class ESWebApiCustomService
    {
        public class Identity2Payload
        {
            public string TextValue { get; set; }
            public int IntValue { get; set; }
            public byte[] ByteArray { get; set; }
            public int[] IntArray { get; set; }
        }

        public struct Identity2Struct
        {
            public string TextValue { get; set; }
            public int IntValue { get; set; }
            public byte[] ByteArray { get; set; }
            public int[] IntArray { get; set; }
        }


        [EbsService]
        public static Identity2Payload Identity2(ESSession session, Identity2Payload payload)
        {
            payload.TextValue += payload.TextValue;
            payload.IntValue += payload.IntValue;
            payload.ByteArray = Enumerable.Range(1, 10).Select(i => (byte)i).ToArray();
            payload.IntArray = Enumerable.Range(1, 10).ToArray();
            return payload;
        }

        [EbsService]
        public static Identity2Struct Identity2Structure(ESSession session, Identity2Struct payload)
        {
            payload.TextValue += payload.TextValue;
            payload.IntValue += payload.IntValue;
            payload.ByteArray = Enumerable.Range(1, 10).Select(i => (byte)i).ToArray();
            payload.IntArray = Enumerable.Range(1, 10).ToArray();
            return payload;
        }

        [EbsService]
        public static Identity2Payload ReturnNull(ESSession session, Identity2Payload payload)
        {
            return null;
        }

        [EbsService]
        public static int SimpleInt(ESSession session, int x)
        {
            return x * x;
        }

        [EbsService]
        public static string ReturnString(ESSession session, Identity2Payload payload)
        {
            return "{0}-{1}".SafeFormat(payload.IntValue, payload.TextValue);
        }


        [EbsService]
        public static int ReturnInt(ESSession session, Identity2Payload payload)
        {
            return payload.IntValue * 2;
        }

        [EbsService]
        public static byte[] ReturnByteArray(ESSession session, Identity2Payload payload)
        {
            return Enumerable.Range(0, payload.IntValue).Select(i => (byte)i).ToArray();

        }

        public static int InvalidService(ESSession session, Identity2Payload payload)
        {
            return payload.IntValue * 2;
        }


    }
}
